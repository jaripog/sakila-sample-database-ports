/* create Login */
USE [master]
GO

/* Create user & Permission for the User*/
/*Password need not be necessarily 'Password123' */

CREATE LOGIN [LWAppUser] WITH PASSWORD=N'Password123', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO
CREATE USER [LWAppUser] FOR LOGIN [LWAppUser]
GO

USE [msdb]
GO
CREATE USER [LWAppUser] FOR LOGIN [LWAppUser]
GO
EXEC sp_addrolemember N'db_datareader', N'LWAppUser'
GO
EXEC sp_addrolemember N'SQLAgentOperatorRole', N'LWAppUser'
GO
EXEC sp_addrolemember N'SQLAgentReaderRole', N'LWAppUser'
GO
EXEC sp_addrolemember N'SQLAgentUserRole', N'LWAppUser'
go
sp_configure 'show advanced options',1
go
reconfigure with override
go
sp_configure 'xp_cmdshell',1
go
reconfigure with override
go
sp_configure 'show advanced options',0
go
reconfigure with override

use master
go
GRANT EXECUTE on xp_cmdshell to LWAppUser
go
use master
go
/* setting LeaseWave windows account as the proxy account to run LeaseWave Jobs. Again password does not necessarily be the same as provided here */
--run in windows auth and in sql server administrator mode
/*Password need not be necessarily 'password-1' */
EXEC sp_xp_cmdshell_proxy_account 'MyMachine\LeaseWave', 'password-1'

/* Sample
EXEC sp_xp_cmdshell_proxy_account 'MyMachine\LeaseWave', 'password-1'
*/
go
CREATE CREDENTIAL [Job] WITH IDENTITY = N'MyMachine\LeaseWave', SECRET = N'password-1'
GO

USE [msdb]
GO
EXEC msdb.dbo.sp_add_proxy @proxy_name=N'LW_JobRunner',@credential_name=N'Job', 
		@enabled=1
GO
EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'LW_JobRunner', @subsystem_id=3
GO
EXEC msdb.dbo.sp_grant_login_to_proxy @proxy_name=N'LW_JobRunner', @login_name=N'LWAppUser'
GO

/* Setting up job Category */

DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'LeaseWave'
go

USE master;
GO
EXEC sp_addlinkedserver 
   N'MyMachine';
GO

USE [LW_Admin]
GO
CREATE USER [LWAppUser] FOR LOGIN [LWAppUser]
go
Grant connect,execute to LWAppUser
GO
EXEC sp_addrolemember N'db_datareader', N'LWAppUser'
GO
EXEC sp_addrolemember N'db_datawriter', N'LWAppUser'
GO

USE [LW_Misc]
GO
CREATE USER [LWAppUser] FOR LOGIN [LWAppUser]
GO
EXEC sp_addrolemember N'db_datareader', N'LWAppUser'
GO
EXEC sp_addrolemember N'db_datawriter', N'LWAppUser'
go
Grant connect,execute to LWAppUser
GO

USE [LW_ErrorLog]
GO
CREATE USER [LWAppUser] FOR LOGIN [LWAppUser]
go
Grant connect,execute to LWAppUser
GO
EXEC sp_addrolemember N'db_datareader', N'LWAppUser'
GO
EXEC sp_addrolemember N'db_datawriter', N'LWAppUser'
GO

USE [LW_Main]
GO
CREATE USER [LWAppUser] FOR LOGIN [LWAppUser]
go
Grant connect,execute to LWAppUser
GO
EXEC sp_addrolemember N'db_datareader', N'LWAppUser'
GO
EXEC sp_addrolemember N'db_datawriter', N'LWAppUser'
GO
grant Alter on Inventory_UDF to LWAppUser
go
grant Alter on Customer_UDF to LWAppUser
go
grant Alter on Lease_UDF to LWAppUser
go
grant alter on CheckRequest_UDF to LWAppUser
go
grant alter on LeaseTransaction_UDF to LWAppUser
go
grant alter on Vendor_UDF to LWAppUser
go
grant Alter on Inventory_UDFList to LWAppUser
go
grant Alter on Customer_UDFList to LWAppUser
go
grant Alter on Lease_UDFList to LWAppUser
go
grant alter on CheckRequest_UDFList to LWAppUser
go
grant alter on LeaseTransaction_UDFList to LWAppUser
go
grant alter on Vendor_UDFList to LWAppUser
go
grant References on UDF_List to LWAppUser
go
 --Format : sp_addlinkedserver '<LW_Admin.dbo.Lessor_Profile.CompanyName>', '', 'SQLNCLI', NULL, NULL, 'SERVER=Database server name;UID=leasewavedbuser;password=<password here>', NULL 

--Following statement needs to be executed for each lessor/company, by varying the first parameter

sp_addlinkedserver 'AMW', '', 'SQLNCLI', NULL, NULL, 'SERVER=<DB Server Name here>;UID=<UserLogin>;password=<Password>', NULL
GO



GRANT EXEC ON dbo.sp_add_job TO PUBLIC
GRANT EXEC ON dbo.sp_add_jobstep TO PUBLIC
GRANT EXEC ON dbo.sp_add_jobserver TO PUBLIC
GRANT EXEC ON dbo.sp_start_job TO PUBLIC 

GRANT EXECUTE ON SP_START_JOB TO TargetServersRole

GRANT EXEC ON dbo.sp_add_jobschedule TO PUBLIC
GRANT SELECT ON dbo.sysjobsteps TO public
GRANT SELECT ON dbo.sysjobs TO public
GRANT EXEC ON dbo.sp_update_jobstep TO PUBLIC 